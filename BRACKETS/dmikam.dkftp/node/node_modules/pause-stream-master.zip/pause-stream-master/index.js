//through@2 handles this by default!
module.exports = require('through')

